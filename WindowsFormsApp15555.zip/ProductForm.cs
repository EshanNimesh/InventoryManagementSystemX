﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace WindowsFormsApp15555
{
    public partial class ProductForm : Form
    {
        string connectionString = "server=localhost;user id=root;password=;database=inventory_db;";

        public ProductForm()
        {
            InitializeComponent();
        }

        private void ProductForm_Load(object sender, EventArgs e)
        {
            LoadCategories();
            LoadProducts();
        }

        private void LoadCategories()
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT CategoryID, CategoryName FROM categories";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                DataTable table = new DataTable();
                adapter.Fill(table);

                cmbCategory.DataSource = table;
                cmbCategory.DisplayMember = "CategoryName";
                cmbCategory.ValueMember = "CategoryID";
            }
        }

        private void LoadProducts()
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT ID, Name, SKU, Quantity, Price, CategoryID FROM products";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dgvProducts.AutoGenerateColumns = true;
                dgvProducts.DataSource = table; // This line refreshes the grid

            }
        }


       

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSKU_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPrice_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void dgvProducts_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvProducts.Rows[e.RowIndex];

                txtName.Text = row.Cells["Name"].Value?.ToString();
                txtSKU.Text = row.Cells["SKU"].Value?.ToString();
                txtQuantity.Text = row.Cells["Quantity"].Value?.ToString();
                txtPrice.Text = row.Cells["Price"].Value?.ToString();

                // Handle category
                if (row.Cells["CategoryID"].Value != DBNull.Value && row.Cells["CategoryID"].Value != null)
                {
                    cmbCategory.SelectedValue = Convert.ToInt32(row.Cells["CategoryID"].Value);
                }
                else
                {
                    cmbCategory.SelectedIndex = -1;
                }
            }
        }
        private void ClearFormFields()
        {
            txtName.Clear();
            txtSKU.Clear();
            txtQuantity.Clear();
            txtPrice.Clear();
            cmbCategory.SelectedIndex = -1; // unselects the dropdown
        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO products (Name, SKU, Quantity, Price, CategoryID) " +
                                   "VALUES (@name, @sku, @quantity, @price, @category_id)";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@name", txtName.Text.Trim());
                        cmd.Parameters.AddWithValue("@sku", txtSKU.Text.Trim());
                        cmd.Parameters.AddWithValue("@quantity", int.Parse(txtQuantity.Text));
                        cmd.Parameters.AddWithValue("@price", decimal.Parse(txtPrice.Text));
                        cmd.Parameters.AddWithValue("@category_id", cmbCategory.SelectedValue ?? DBNull.Value);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Product added successfully!");
                        LoadProducts(); // Refresh the DataGridView
                        ClearFormFields(); // <<< Add this line here
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            if (dgvProducts.CurrentRow != null)
            {
                int productId = Convert.ToInt32(dgvProducts.CurrentRow.Cells["ID"].Value);

                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "UPDATE products SET Name = @name, SKU = @sku, Quantity = @quantity, Price = @price, CategoryID = @category_id WHERE ID = @id";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", productId);
                    cmd.Parameters.AddWithValue("@name", txtName.Text);
                    cmd.Parameters.AddWithValue("@sku", txtSKU.Text);
                    cmd.Parameters.AddWithValue("@quantity", int.Parse(txtQuantity.Text));
                    cmd.Parameters.AddWithValue("@price", decimal.Parse(txtPrice.Text));
                    cmd.Parameters.AddWithValue("@category_id", cmbCategory.SelectedValue);

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    LoadProducts();
                    MessageBox.Show("Product updated successfully!"); // ✅ Show message
                    ClearFormFields(); // ✅ Clear form
                }
            }
        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            if (dgvProducts.CurrentRow != null)
            {
                int productId = Convert.ToInt32(dgvProducts.CurrentRow.Cells["ID"].Value);

                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "DELETE FROM products WHERE ID = @id";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", productId);

                    cmd.ExecuteNonQuery();
                    conn.Close();
                    LoadProducts();
                    MessageBox.Show("Product deleted successfully!"); // ✅ Show message
                    ClearFormFields(); // ✅ Clear form
                }
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
